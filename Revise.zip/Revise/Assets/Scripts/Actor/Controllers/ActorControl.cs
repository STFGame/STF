﻿using Actor.Bubbles;
using Actor.Movements;
using Actor.StateBehaviours;
using Controls;
using Controls;
using UnityEngine;
using Utility;

namespace Actor
{
    /// <summary>ActorControl controls the Actor by passing in different values to the movement component.</summary>
    [RequireComponent(typeof(ActorMovement), typeof(ActorCombat), typeof(ActorSurvival))]
    public class ActorControl : MonoBehaviour
    {
        public PlayerNumber playerNumber;

        private ActorMovement actorMovement;
        private ActorCombat actorCombat;
        private ActorSurvival actorSurvival;
        private ControlManager comboManager;

        private MasterBehaviour masterBehaviour;

        [HideInInspector] public Device device = null;

        [Header("Gravity Controls")]
        [SerializeField] private Gravity gravity = new Gravity();

        [Header("Movement Controls")]
        [SerializeField] private AxisControl dashControl = new AxisControl();
        [SerializeField] private AxisControl crouchControl = new AxisControl();
        [SerializeField] private AxisControl descendControl = new AxisControl();

        public MovementState MovementState { get; private set; }

        private StateMachine currentState = StateMachine.Idle;
        private Vector3 move = Vector3.zero;
        private bool onGround = true;

        #region Initialization
        private void Awake()
        {
            actorMovement = GetComponent<ActorMovement>();
            actorCombat = GetComponent<ActorCombat>();
            actorSurvival = GetComponent<ActorSurvival>();
            comboManager = GetComponentInChildren<ControlManager>();

            MovementState = MovementState.Regular;

            if (playerNumber != PlayerNumber.None)
            {
                string name = Input.GetJoystickNames()[(int)playerNumber - 1];
                device = new Device(name, (int)playerNumber);
            }
        }

        private void OnEnable()
        {
            masterBehaviour = GetComponent<Animator>().GetBehaviour<MasterBehaviour>();

            masterBehaviour.StateEvent += UpdateState;
        }

        private void Start()
        {
            GetComponentInChildren<BubbleManager>().GetGroundBubble(BodyArea.Base).GetComponent<Bubble>().GroundEvent += Grounded;

        }

        private void OnDisable()
        {
            masterBehaviour.StateEvent -= UpdateState;
        }
        #endregion

        private void Update()
        {
            if (device == null)
                return;

            move = new Vector3(device.LeftStick.Horizontal, device.LeftStick.Vertical, 0f);

            device.UpdateDevice();

            comboManager.UpdateControl(device);

            Combat();
            Survival(move);

            ControlMovement();
        }

        private void FixedUpdate()
        {
            if (device == null)
                return;

            Move(move);
        }

        private void Survival(Vector3 move)
        {
            bool block = device.RightBumper.Hold;

            actorSurvival.PerformSurvival(block);

            actorSurvival.Roll(move);

            actorSurvival.Dodge(move);

            actorSurvival.PlaySurvivalAnimation();
        }

        private void Combat()
        {
            actorCombat.PerformAttack();
            actorCombat.PlayAttackAnimation();
        }

        #region Movement
        private void Move(Vector3 move)
        {
            bool jumpCommand = device.LeftBumper.Trigger;
            bool jumpHold = device.LeftBumper.Hold;

            if (CanMove())
            {
                actorMovement.Move(move);
                actorMovement.PlayMovementAnimations(move);
            }

            if (CanJump())
            {
                actorMovement.Jump(move.y, jumpCommand, jumpHold);
                actorMovement.PlayJumpAnimations(move, jumpCommand);
            }

            if (CanRotate())
                actorMovement.Rotate(move.x, actorSurvival.IsBlocking);

            device.LeftBumper.Trigger = false;
        }

        private bool CanJump()
        {
            bool canJump = true;

            if (currentState == StateMachine.Stun)
                canJump = false;

            return canJump;
        }

        private bool CanRotate()
        {
            bool canRotate = true;

            if (currentState == StateMachine.Stun)
                canRotate = false;

            return canRotate;
        }

        private bool CanMove()
        {
            bool canMove = true;

            if (currentState == StateMachine.Block || currentState == StateMachine.Dodge ||
                currentState == StateMachine.Roll || currentState == StateMachine.Stun)
                canMove = false;

            return canMove;
        }

        private void ControlMovement()
        {
            actorMovement.IsDashing = dashControl.IsSuccessful(device.LeftStick.Horizontal);
            actorMovement.IsCrouching = crouchControl.IsSuccessful(device.LeftStick.Vertical);
            actorMovement.IsTurning = device.LeftStick.Horizontal * transform.forward.x < 0f;
            actorMovement.IsFastFalling = descendControl.IsSuccessful(device.LeftStick.Vertical) && !actorMovement.OnGround;

            MovementState state = MovementState.None;

            if (dashControl.IsSuccessful(device.LeftStick.Horizontal))
            {
                state = MovementState.Dash;
            }
            else if (crouchControl.IsSuccessful(device.LeftStick.Vertical))
            {
                state = MovementState.Crouch;
            }
            else if (descendControl.IsSuccessful(device.LeftStick.Vertical) && !actorMovement.OnGround)
            {
                state = MovementState.Descend;
            }
            else if (device.LeftStick.Horizontal * transform.forward.x < 0f)
            {
                state = MovementState.Turn;
            }
            else
            {
                state = MovementState.Regular;
            }

            actorMovement.UpdateMovementState(state);
        }
        #endregion

        private void UpdateState(StateMachine updateState)
        {
            //Debug.Log(currentState);
            currentState = updateState;
        }

        private void Grounded(bool onGround)
        {
            this.onGround = onGround;
        }

        private void OnDrawGizmos() { }
    }
}
