﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Actor.Combat
{
    public enum AttackAnimation
    {
        None,
        LightAttack1,
        LightAttack2,
        LightAttack3,

        HeavyAttack1,
        HeavyAttack2,
        HeavyAttack3
    }
}
