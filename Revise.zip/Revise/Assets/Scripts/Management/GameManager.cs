﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Management
{
    public class GameManager : MonoBehaviour
    {
        public float time = 500f;

        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}