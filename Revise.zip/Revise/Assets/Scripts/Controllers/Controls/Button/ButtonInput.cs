﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Controls
{
    public enum ButtonInput
    {
        Action1,
        Action2,
        Action3,
        Action4,

        LeftStick,
        RightStick,

        LeftBumper,
        RightBumper,

        LeftTrigger,
        RightTrigger,
    }
}
