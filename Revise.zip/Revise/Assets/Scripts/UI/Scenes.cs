﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Scene
{
    StartScene,
    CharacterSelectScene,
    TestScene
}
