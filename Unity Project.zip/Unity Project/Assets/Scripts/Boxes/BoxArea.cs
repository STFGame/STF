﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public enum BoxArea
{
    None,

    Head,
    UpperTorso,
    MidTorso,
    LowerTorso,
    Hips,

    RightShoulder,
    RightBicep,
    RightElbow,
    RightForearm,
    RightWrist,
    RightHand,

    LeftShoulder,
    LeftBicep,
    LeftElbow,
    LeftForearm,
    LeftWrist,
    LeftHand,

    RightThigh,
    RightKnee,
    RightCalf,
    RightAnkle,
    RightFoot,
    RightToe,

    LeftThigh,
    LeftKnee,
    LeftCalf,
    LeftAnkle,
    LeftFoot,
    LeftToe,
}
