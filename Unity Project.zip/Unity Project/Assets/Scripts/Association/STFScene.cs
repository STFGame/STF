﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Association
{
    public enum STFScene
    {
        Quit = -1,
        MainMenuScene = 0,
        CharacterSelectScene = 1,
        PlayScene = 2,
    }
}