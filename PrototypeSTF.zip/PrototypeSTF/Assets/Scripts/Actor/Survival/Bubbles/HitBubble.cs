﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Actor.Bubbles
{
    public sealed class HitBubble : Bubble
    {
        protected override void OnTriggerEnter(Collider other)
        {
            throw new System.NotImplementedException();
        }

        protected override void OnTriggerExit(Collider other)
        {
            throw new System.NotImplementedException();
        }
    }
}