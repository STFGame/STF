﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Controls
{
    public class ProfileNameList
    {
        public static string[] PlayStation = new string[]
        {
            "Wireless Controller"
        };

        public static string[] Xbox = new string[]
        {
            "Controller (Afterglow Gamepad for Xbox 360)"
        };
    }
}
