﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Controls
{
    public enum PlayerNumber
    {
        None,

        Player1,
        Player2,
        Player3,
        Player4
    }
}
